﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace BillingService
{
   public class Program
    {
        public static void Main(string[] args)
        {
            var ResList = new List<KeyValuePair<string, int>>();
            float drinksTotal = 0;
            float foodTotal = 0;
            var numberOfDecimalPlaces = 2;
            var multiplier = Math.Pow(10, numberOfDecimalPlaces);
            // adding Purchased items
            ResList.Add(new KeyValuePair<string, int>("Cola - Cold", 50));
            ResList.Add(new KeyValuePair<string, int>("Coffee - Hot", 100));
            ResList.Add(new KeyValuePair<string, int>("Cheese Sandwich - Cold", 120));
            ResList.Add(new KeyValuePair<string, int>("Steak Sandwich -Hot", 450));
            Console.WriteLine("Your Order :");
            try
            {
                PurchasedItems(ResList, ref drinksTotal, ref foodTotal);
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }

             Subtotal(drinksTotal, foodTotal, multiplier);
           
            static void PurchasedItems(List<KeyValuePair<string, int>> ResList, ref float drinksTotal, ref float foodTotal)
            {
                foreach (var val in ResList)
                {
                    Console.WriteLine(val);

                    if ((val.Key.Contains("Cola")) || (val.Key.Contains("Coffee")))
                    {
                        drinksTotal = val.Value + drinksTotal;

                    }
                    else
                    {
                        foodTotal = val.Value + foodTotal;

                    }
                }
            }

            static float Subtotal(float drinksTotal, float foodTotal, double multiplier)
            {
                float subtotal = (float)((drinksTotal + foodTotal + (foodTotal * 0.1)) / 100);
                subtotal = (float)(Math.Ceiling(subtotal * multiplier) / multiplier);
                Console.WriteLine("SubTotal:" + "$" + subtotal);
                return subtotal;
            }
        }
    }
}
